﻿using System;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;
using Utilla;

namespace Kick
{
    [BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
    public class Plugin : BaseUnityPlugin
    {
        void Start()
        {
            new Harmony("PATCHES").PatchAll(Assembly.GetExecutingAssembly());
            StartCoroutine(HarmonyPatches.Patch());
        }

        void Update()
        {
            foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in GorillaScoreboardTotalUpdater.allScoreboardLines)
            {
                foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
                {
                    if (((double)Vector3.Distance(vrrig.rightHandTransform.position, gorillaPlayerScoreboardLine.reportButton.gameObject.transform.position) < 0.59) || ((double)Vector3.Distance(vrrig.leftHandTransform.position, gorillaPlayerScoreboardLine.reportButton.gameObject.transform.position) < 0.59))
                    {
                        var ownershipGuard = GameObject.Find("WorldShareableCosmetic").GetComponent<WorldShareableItem>().guard;
                        ownershipGuard.TransferOwnership(vrrig.Creator, "");
                        if (ownershipGuard != null)
                        {
                            ownershipGuard.photonView.RpcSecure("OwnershipRequested", vrrig.Creator.GetPlayerRef(), true, new object[]
                            {
                            "$_$".PadLeft(1966)
                            });
                        }
                        GorillaNot.instance.checkCooldown = float.MaxValue;
                        Traverse.Create(GorillaNot.instance).Field("playerID").SetValue("");
                        Traverse.Create(GorillaNot.instance).Field("playerNick").SetValue("");
                        Traverse.Create(GorillaNot.instance).Field("_suspiciousPlayerId").SetValue("");
                        Traverse.Create(GorillaNot.instance).Field("_suspiciousPlayerName").SetValue("");
                        Traverse.Create(GorillaNot.instance).Field("_suspiciousReason").SetValue("");
                        Traverse.Create(GorillaNot.instance).Field("_sendReport").SetValue(false);
                        Traverse.Create(GorillaNot.instance).Field("reportedPlayers").SetValue(null);
                    }

                }
            }
        
        }

        [HarmonyPatch(typeof(RequestableOwnershipGuard), "OwnershipRequested")]
        internal class AntiKick : MonoBehaviour
        {
            private static bool Prefix()
            {
                return false;
            }
        }
    }
}
